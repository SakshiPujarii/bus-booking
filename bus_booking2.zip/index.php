﻿<?php
    error_reporting(0);
    require_once "bookHelper.php";
    
    $helper    = new BookHelper();
    $locations = $helper->getLocationData(0,1);
  
?>
<!doctype html>
<!--[if IE 7 ]>    <html class="ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8 oldie" lang="en"> <![endif]-->
<!--[if IE 	 ]>    <html class="ie" lang="en"> <![endif]-->
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<html>
<head>
	<meta charset="utf-8">
	<title>Bus Booking</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen,projection,print" />
	<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />
    
    <link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css"/>
     
	<link rel="shortcut icon" href="images/favicon.ico" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/sequence.jquery-min.js"></script>
	<script type="text/javascript" src="js/jquery.uniform.min.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/sequence.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
	<script type="text/javascript">	
		$(document).ready(function(){
			$(".form").hide();
			$(".form:first").show();
			$(".f-item:first").addClass("active");
			$(".f-item:first span").addClass("checked");
		});
	</script>
    
    <!---------------------------- Validation ------------------------------------------>
    <script src="js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#main-search").validationEngine();
		});
	</script>
    <!---------------------------- Validation ------------------------------------------>
    <style>.main{min-height: 315px;}</style>
</head>
<body>
	<!--header-->
	<?php
    
    require_once "header.php";
    ?>
	<!--//header-->
	
	<!--slider-->
	<section class="slider clearfix">
		<div id="sequence">
			<ul>
				<li>
					<img class="main-image animate-in" src="images/slider/img3.jpg" alt="" />
				</li>
				<li>
					<img class="main-image animate-in" src="images/slider/img1.jpg" alt="" />
				</li>
				<li>
					<img class="main-image animate-in" src="images/slider/img2.jpg" alt="" />
				</li>
			</ul>
		</div>
	</section>
	<!--//slider-->
	
	<!--search-->
	<div class="main-search">
		<form id="main-search" method="post" action="search_results.php">
			<!--column-->
			<div class="column radios">
				<h4><span>01</span> What?</h4>
				
				<div class="f-item">
					<input type="radio" name="radio" id="flight" value="form3" />
					<label for="flight">Bus Search</label>
				</div>
			</div>
			<!--//column-->
			
			<div class="forms">
				
				<!--form flight-->
				<div class="form" id="form3">
					<!--column-->
					<div class="column">
						<h4><span>02</span> Where?</h4>
						<div class="f-item">
							<label for="destination3">Leaving from</label>
                            <select id="from" name="from" class="validate[required]">
                                <option value="">Select City</option>
								<?php
                                foreach($locations as $location)
                                {
                                    ?>
                                    <option value="<?php echo $location['id'];?>"><?php echo $location['location'];?></option>
                                    <?php
                                }
                                ?>
							</select>
						</div>
						<div class="f-item">
							<label for="destination4">Going to</label>
                            <select id="to" name="to" class="validate[required]">
                                <option value="">Select City</option>
								<?php
                                foreach($locations as $location)
                                {
                                    ?>
                                    <option value="<?php echo $location['id'];?>"><?php echo $location['location'];?></option>
                                    <?php
                                }
                                ?>
							</select>
						</div>
					</div>
					<!--//column-->
					
					<!--column-->
					<div class="column two-childs">
						<h4><span>03</span> When?</h4>
						<div class="f-item datepicker">
							<label for="datepicker6">Departing on</label>
							<div class="datepicker-wrap">
                            <input type="text" placeholder="" id="datepicker6" name="datepicker6" class="validate[custom[date],future[NOW]] validate[required]" /></div>
						</div>
					</div>
					<!--//column-->
				</div>	
				<!--//form flight-->
			</div>
			<input type="submit" value="Proceed to results" class="search-submit" id="search-submit" />
		</form>
	</div>
	<!--//search-->
	
	<!--main-->
	<div class="main" role="main">
		<div class="wrap clearfix">
			<!--info boxes-->
			<section class="boxes clearfix">
				<h1>Why Book With Us?</h1>
				<!--column-->
				<article class="one-fourth">
					<h2>Best Price Guarantee</h2>
					<p>We offer the best buses at the best prices. If you find the same buses on the same dates cheaper elsewhere, we will refund the difference. Guaranteed, and quickly. </p>
				</article>
				<!--//column-->
				
				<!--column-->
				<article class="one-fourth">
					<h2>Secure Booking</h2>
					<p>Bus Booking reservation system is secure and personal information is encrypted.<br />We work to high standards and guarantee your privacy. </p>
				</article>
				<!--//column-->
				
				<!--column-->
				<article class="one-fourth">
					<h2>Benefits for Traveller</h2>
					<p>We provide a cost-effective model, a network of over 5000 partners and a personalised account management service to help you optimise your revenue.</p>
				</article>
				<!--//column-->
				
				<!--column-->
				<article class="one-fourth last">
					<h2>Any Questions?</h2>
					<p>Call us on <em>+91-1234567890</em> for individual, tailored advice for your perfect stay or <a href="contact.php" title="Contact">send us a message</a> with your bus booking query.<br /><br /></p>
				</article>
				<!--//column-->
			</section>
			<!--//info boxes-->
		</div>
	</div>
	<!--//main-->
	
	<!--footer-->
	<?php
    require_once "footer.php";
    ?>
	<!--//footer-->

</body>
</html>