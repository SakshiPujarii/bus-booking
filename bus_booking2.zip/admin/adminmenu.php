<ul id="navigation">
	<li><a href="dashboard.php" class="active">Home</a></li>
    <li><a href="reservations.php">Reservations</a></li>
    <li><a href="routes.php">Routes</a></li>
    <li><a href="locations.php">Locations</a></li>
    <li><a href="busses.php">Busses</a></li>
    <li><a href="users.php">Users</a></li>
</ul>