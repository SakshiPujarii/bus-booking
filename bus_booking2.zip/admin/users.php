  <?php
    error_reporting(0);
    session_start();
    require_once "../inc/config.php";
    require_once "../inc/dbhelper.php";
    
    $db=new Database();
    $db->open();
    
?>
<?php
    $msg="";
    $block="";
    $class="";
    
    //var_dump($_POST,$_FILES);die;
    $task=$_POST['task'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $last_name=$_POST['last_name'];
    $first_name=$_POST['first_name'];
    $email=$_POST['email'];
    $description=$_POST['description'];
    $id=$_POST['id'];
    $creator=$_SESSION['userid'];
    $created_date = date("Y-m-d H:i:s"); 
    
    $published=$_POST['published'];
    
    if($task=='create')
    {
        if($id)
        {
            $sql="UPDATE `jos_admins` SET username='".$username."',password='".$password."',last_name='".$last_name."',first_name='".$first_name."',email='".$email."',published=".$published.",created_date='".$created_date."' WHERE id=".$id;
            $msg="Updated";
        }
        else
        {
            $sql = "INSERT INTO `jos_admins` (`id`, `username`, `password`, `last_name`,`first_name`,  `published`,`created_date`,`email`)
                    VALUES (NULL, '".$username."', '".$password."', '".$last_name."','".$first_name."', ".$published.",'".$created_date."','".$email."')";
            $msg="Inserted";
        } 
       
        $result = $db->query($sql);
        if($result) 
        {
            $msg="Record ".$msg;
            $class="n-success";
        }
        else
        {
            $msg="Record not ".$msg;
            $class="n-error";
        }
        

        $block="display:block";   
       
    }
 
 
    $id=$_GET['id'];
    $action=$_GET['action'];
    $published=$_GET['published'];
    
    if($action=='update')
    {
        $sql="UPDATE `jos_admins` SET published=$published WHERE id=".$id;
        $result=$db->query($sql);
        
        $msg="updated";
        $block="display:block";
        if($result) 
        {
            $msg="Record ".$msg;
            $class="n-success";
        }
        else
        {
            $msg="Record not ".$msg;
            $class="n-error";
        }
    }
    
    if($action=='remove')
    {
        $sql="DELETE FROM `jos_admins` WHERE id=".$id;
        $result=$db->query($sql);
        
        $msg="removed";
        $block="display:block";
        if($result) 
        {
            $msg="Record ".$msg;
            $class="n-success";
        }
        else
        {
            $msg="Record not ".$msg;
            $class="n-error";
        }
    }
 
 
    
     $sql="SELECT * FROM `jos_admins`";
     $result=$db->query($sql);
?>
    
   



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
		<title>Bus Booking Admin</title>
		<link rel="stylesheet" href="css/960.css" type="text/css" media="screen" charset="utf-8" />
		<!--<link rel="stylesheet" href="css/fluid.css" type="text/css" media="screen" charset="utf-8" />-->
		<link rel="stylesheet" href="css/template.css" type="text/css" media="screen" charset="utf-8" />
		<link rel="stylesheet" href="css/colour.css" type="text/css" media="screen" charset="utf-8" />
	</head>
	<body>
    <div id="head">
        <span style="float:right">Welcome <?php echo $_SESSION['username'];?><a href="logout.php">Logout</a></span>
        <h1>Bus Booking Admin</h1>
	</div>	
	<?php
            require_once "adminmenu.php";
    ?>
    	
		
		<div id="content" class="container_16 clearfix">
            
				<div class="grid_16">
                
                <span class="notification <?php echo $class;?>" style="<?php echo $block;?>"><?php echo $msg;?></span>
                    <form method="get">
				    	<table>
                        
                        
						<thead>
							<tr>
								<th>User Name</th>
								<th>Password</th>
								<th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Published</th>
								<th colspan="2" width="10%">Actions</th>
							</tr>
						</thead>
						<tbody>
							 <?php   
                                 while($row=$db->fetcharray($result))
                                 {
                                   ?>
                                   <tr>
                                   <td><?php echo $row['username'];?></td>
                                   <td><?php echo $row['password'];?> </td>
                                   <td><?php echo $row['first_name'];?></td>
                                   <td><?php echo $row['last_name'];?></td>
                                   <td><?php echo $row['email'];?></td>
                                   <?php
                                   $p=$row['published'];
                                   if($p)
                                   {
                                    ?>
                                         <td><a href="users.php?id=<?php echo $row['id']?>&action=update&published=0"><img src="images/tick-circle.gif" /></a></td>
                                         <?php
                                   }
                                   else
                                   {
                                    ?>
                                        <td><a href="users.php?id=<?php echo $row['id']?>&action=update&published=1"><img src="images/minus-circle.gif" /></a></td>
                                        <?php
                                   }
                                   ?>
                                  
                                   <td><a href="user.php?id=<?php echo $row['id'];?>" class="edit">Edit</a></td>
								   <td><a href="users.php?id=<?php echo $row['id'];?>&action=remove" class="delete">Delete</a></td>
                                   </tr> 
                                   <?php
                                 }  
                                 ?> 
						
						</tbody>
				    	</table>
                    </form>
				</div>
			</div>
		
		<div id="foot">
			Copyright <?php echo date('Y');?> Bus Booking Admin. All rights reserved.
		</div>
	</body>
</html>