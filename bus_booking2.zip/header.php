<header>
	<div class="wrap clearfix">
		<!--logo-->
		<h1 class="logo"><a href="index.php" title="Bus Booking"><img src="images/txt/logo.png" alt="Bus Booking" /></a></h1>
		<!--//logo-->
		
		<!--contact-->
		<div class="contact">
			<span>24/7 Support number</span>
			<span class="number">+91-1234567890</span>
		</div>
		<!--//contact-->
	</div>
	
	<!--main navigation-->
	<nav class="main-nav no-print" role="navigation">
		<ul class="wrap">
			<li><a href="index.php">Home</a></li>
            <li><a href="checkstatus.php">Check Status</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact Us</a></li>
		</ul>
	</nav>
	<!--//main navigation-->
</header>